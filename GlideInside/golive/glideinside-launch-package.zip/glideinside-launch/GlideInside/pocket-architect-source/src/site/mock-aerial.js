// The "aerial" for the sample lots in mock mode, so the underlay and the 3D terrain texture have something to show. When the real
// NSW sample photograph exists (tools/fixtures/sample-aerial.jpg in Node, or CONFIG.siteMockAerialUrl in a browser) it is laid over
// the lot extent as mirrored tiles; when it is missing a synthetic picture (roads, lawns, roofs, trees) is drawn instead, which is a
// picture of nothing real.

import { rng, ROOFS, frontFrame, houseSpec, streetTreeSpots } from './neighbours.js';

// Speckle: many tiny marks in a colour range, so a flat fill reads as lawn, concrete or asphalt at full resolution.
function speckle(g, rand, w, h, count, size, palette, alpha = 0.5) {
  for (let i = 0; i < count; i++) {
    g.globalAlpha = alpha * (0.4 + rand() * 0.6);
    g.fillStyle = palette[Math.floor(rand() * palette.length)];
    g.fillRect(rand() * w, rand() * h, size * (0.6 + rand()), size * (0.6 + rand()));
  }
  g.globalAlpha = 1;
}

function tree(g, rand, x, y, r) {
  g.save();
  g.fillStyle = 'rgba(0,0,0,0.26)';
  g.beginPath();
  g.ellipse(x + r * 0.28, y + r * 0.34, r * 1.02, r * 0.9, 0, 0, Math.PI * 2);
  g.fill();
  const grad = g.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r);
  grad.addColorStop(0, '#5f9047');
  grad.addColorStop(0.65, '#3f7036');
  grad.addColorStop(1, '#2b5226');
  g.fillStyle = grad;
  g.beginPath();
  for (let a = 0; a < 18; a++) {
    const ang = (a / 18) * Math.PI * 2;
    const rr = r * (0.86 + rand() * 0.2);
    g[a ? 'lineTo' : 'moveTo'](x + Math.cos(ang) * rr, y + Math.sin(ang) * rr);
  }
  g.closePath();
  g.fill();
  for (let k = 0; k < 14; k++) {
    g.fillStyle = `rgba(${120 + rand() * 50},${170 + rand() * 40},${90 + rand() * 30},0.22)`;
    g.beginPath();
    g.arc(x + (rand() - 0.6) * r, y + (rand() - 0.6) * r, r * (0.1 + rand() * 0.16), 0, Math.PI * 2);
    g.fill();
  }
  g.restore();
}

// Drawn finer than the nominal pixel size so the sample is sharp at close range (the aerial is a picture of nothing real).
export function mockAerialSize(meta) {
  const w = Math.min(3584, Math.max(meta.widthPx, 3072));
  return { w, h: Math.round(meta.widthPx ? (w * meta.heightPx) / meta.widthPx : meta.heightPx) };
}

/** The sample photograph as bytes, or null when it is not available (then the synthetic picture is drawn). */
export async function sampleAerialBytes(url = null) {
  try {
    if (typeof process !== 'undefined' && process.versions?.node && typeof document === 'undefined') {
      const fsName = 'node:fs';
      const fs = await import(/* @vite-ignore */ fsName);
      const f = new URL('../../tools/fixtures/sample-aerial.jpg', import.meta.url);
      return fs.existsSync(f) ? new Uint8Array(fs.readFileSync(f)) : null;
    }
    if (url && typeof fetch === 'function') {
      const r = await fetch(url);
      return r.ok ? new Uint8Array(await r.arrayBuffer()) : null;
    }
  } catch { /* fall back to the synthetic picture */ }
  return null;
}

async function decodeSample(bytes) {
  if (typeof createImageBitmap === 'function') return createImageBitmap(new Blob([bytes]));
  const spec = '@napi-rs/canvas';
  return (await import(/* @vite-ignore */ spec)).loadImage(Buffer.from(bytes));
}

/** The real photograph over the lot extent: mirrored tiles about 600 m across, so the picture is sharp at lot scale and has no seams. */
async function drawSampleAerial(g, w, h, meta, bytes) {
  const img = await decodeSample(bytes);
  const b = meta.bbox;
  const tileM = 600;
  const tw = tileM;
  const th = tileM * (img.height / img.width);
  const sx = w / (b.maxE - b.minE);
  const sy = h / (b.maxN - b.minN);
  const e0 = 0;
  const n0 = 0;
  for (let i = Math.floor(e0 / tw); i <= Math.floor((e0 + b.maxE - b.minE) / tw); i++) {
    for (let j = Math.floor(n0 / th); j <= Math.floor((n0 + b.maxN - b.minN) / th); j++) {
      const dw = tw * sx;
      const dh = th * sy;
      const fx = i % 2 !== 0;
      const fy = j % 2 !== 0;
      g.save();
      g.translate((i * tw - e0) * sx + (fx ? dw : 0), h - (j + 1) * th * sy + n0 * sy + (fy ? dh : 0));
      g.scale(fx ? -1 : 1, fy ? -1 : 1);
      g.drawImage(img, 0, 0, dw + 1, dh + 1);
      g.restore();
    }
  }
}

export async function mockAerialBlob(meta, lotResp, { sampleUrl = null } = {}) {
  const { w, h } = mockAerialSize(meta);
  const canvas = typeof OffscreenCanvas !== 'undefined' ? new OffscreenCanvas(w, h) : Object.assign(document.createElement('canvas'), { width: w, height: h });
  const g = canvas.getContext('2d');
  const sample = await sampleAerialBytes(sampleUrl);
  if (sample) {
    try {
      await drawSampleAerial(g, w, h, meta, sample);
      return await canvasBlob(canvas);
    } catch { /* the synthetic picture below */ }
  }
  const o = lotResp.origin;
  const b = meta.bbox;
  const ppm = w / (b.maxE - b.minE);
  const px = (dx) => ((dx - (b.minE - o.e)) / (b.maxE - b.minE)) * w;
  const py = (dn) => (((b.maxN - o.n) - dn) / (b.maxN - b.minN)) * h;
  const rand = rng(7);
  const lots = [lotResp.lot, ...lotResp.neighbours];
  const rings = lots.map((l) => l.polygons[0].outer);
  const trace = (ring) => {
    g.beginPath();
    ring.forEach(([x, y], i) => (i ? g.lineTo(px(x), py(y)) : g.moveTo(px(x), py(y))));
    g.closePath();
  };

  // Street: asphalt with wear and fine grain
  g.fillStyle = '#54575a';
  g.fillRect(0, 0, w, h);
  speckle(g, rand, w, h, Math.round(w * h / 18), 1.2, ['#484b4e', '#62656a', '#585b5e', '#6c6f72'], 0.6);

  // Street edge of every lot, outside in: gutter and kerb (to 4.45 m from the property line), grass verge, footpath (0.85 to 2.35 m)
  // and a strip of grass inside the property line. Shared boundaries are covered by the lawns drawn after.
  g.lineJoin = 'miter';
  for (const [wm, col] of [[8.9, '#9c9a93'], [8.0, '#6f9356'], [4.7, '#c6c4bb'], [1.7, '#6f9356']]) {
    for (const ring of rings) {
      trace(ring);
      g.lineWidth = wm * ppm;
      g.strokeStyle = col;
      g.stroke();
    }
  }
  // Lawns: mottled, with mowing stripes
  for (const ring of rings) {
    trace(ring);
    g.fillStyle = `rgb(${98 + Math.floor(rand() * 16)},${134 + Math.floor(rand() * 16)},${74 + Math.floor(rand() * 12)})`;
    g.fill();
    g.save();
    trace(ring);
    g.clip();
    // soft mowing patches 1 to 4 m across (read at ground level), faint so the lawn reads as one surface
    for (let k = 0; k < 260; k++) {
      const rx = (0.8 + rand() * 2.6) * ppm;
      g.globalAlpha = 0.035 + rand() * 0.05;
      g.fillStyle = rand() > 0.5 ? '#a8c47a' : '#3f6a34';
      g.beginPath();
      g.ellipse(rand() * w, rand() * h, rx, rx * (0.4 + rand() * 0.5), rand() * Math.PI, 0, Math.PI * 2);
      g.fill();
    }
    g.globalAlpha = 1;
    speckle(g, rand, w, h, Math.round(w * h / 70), 1.7, ['#79ab5a', '#4f7f3d', '#88b565', '#5c8f46', '#9bbb72', '#3f6c35'], 0.5);
    g.restore();
  }

  lots.forEach((l, li) => {
    const f = frontFrame(rings, li);
    const { fm, ux, uy, nx, ny, W, depth } = f;
    const spec = houseSpec(W, depth, li);
    const { hw, hd, setback, side } = spec;
    const [roofA, roofB] = ROOFS[spec.roofIdx];
    g.save();
    // Local metres: a along the front edge, b into the lot
    const o0 = [px(fm[0]), py(fm[1])];
    const ua = [px(fm[0] + ux) - o0[0], py(fm[1] + uy) - o0[1]];
    const nb = [px(fm[0] + nx) - o0[0], py(fm[1] + ny) - o0[1]];
    g.transform(ua[0], ua[1], nb[0], nb[1], o0[0], o0[1]);
    trace2(g, rings[li], fm, ux, uy, nx, ny);
    g.clip();
    // Boundary fence line
    g.lineWidth = 0.14;
    g.strokeStyle = 'rgba(120,114,100,0.85)';
    trace2(g, rings[li], fm, ux, uy, nx, ny);
    g.stroke();
    if (li === 0) {
      // The subject lot is left clear: the person places their own house here.
      g.restore();
      return;
    }
    // Driveway and path
    const dw = 3.4;
    const dx0 = side * (hw / 2 - dw / 2 - 0.4);
    g.fillStyle = '#b9b6ac';
    g.fillRect(dx0 - dw / 2, -0.5, dw, setback + 1.2);
    g.strokeStyle = 'rgba(90,88,80,0.35)';
    g.lineWidth = 0.05;
    for (let k = 2; k < setback + 1; k += 2.6) {
      g.beginPath();
      g.moveTo(dx0 - dw / 2, k);
      g.lineTo(dx0 + dw / 2, k);
      g.stroke();
    }
    g.fillStyle = '#c9c5ba';
    g.fillRect(-side * hw * 0.18 - 0.5, 0, 1, setback + 0.6);
    // Roof shadow, then the roof as two pitches around a ridge along the front edge
    const hx0 = -hw / 2;
    const hy0 = setback;
    g.fillStyle = 'rgba(0,0,0,0.30)';
    g.fillRect(hx0 + 1.2, hy0 + 1.4, hw, hd);
    g.fillStyle = roofA;
    g.fillRect(hx0, hy0, hw, hd / 2);
    g.fillStyle = roofB;
    g.fillRect(hx0, hy0 + hd / 2, hw, hd / 2);
    g.strokeStyle = 'rgba(0,0,0,0.30)';
    g.lineWidth = 0.14;
    g.strokeRect(hx0, hy0, hw, hd);
    g.beginPath();
    g.moveTo(hx0 + 1.6, hy0 + hd / 2);
    g.lineTo(hx0 + hw - 1.6, hy0 + hd / 2);
    g.stroke();
    g.lineWidth = 0.06;
    g.strokeStyle = 'rgba(0,0,0,0.10)';
    for (let k = hx0 + 0.5; k < hx0 + hw; k += 0.55) {
      g.beginPath();
      g.moveTo(k, hy0);
      g.lineTo(k, hy0 + hd);
      g.stroke();
    }
    // Garage wing towards the street over the driveway
    g.fillStyle = 'rgba(0,0,0,0.25)';
    g.fillRect(dx0 - 3.2 + 0.8, setback + 0.2, 6.4, 1.6);
    g.fillStyle = roofA;
    g.fillRect(dx0 - 3.2, setback - 0.1, 6.4, 1.6);
    // Rear: shed, pool, trees
    const rand = rng(500 + li);
    const sx = -side * (W * 0.28);
    g.fillStyle = '#7a7f82';
    g.fillRect(sx - 1.6, depth - 5, 3.2, 2.6);
    if (spec.hasPool) {
      g.fillStyle = '#c8d4d8';
      g.fillRect(side * 1.5 - 2.3, hy0 + hd + 2.2 - 0.3, 5.1, 9.1 / 2 + 0.2);
      g.fillStyle = '#3fa2c4';
      g.fillRect(side * 1.5 - 2, hy0 + hd + 2.2, 4.5, 4.4);
    }
    for (let t = 0; t < 3; t++) {
      const ta = (rand() - 0.5) * W * 0.8;
      const tb = hy0 + hd + 3 + rand() * Math.max(2, depth - hy0 - hd - 6);
      tree(g, rand, ta, tb, 1.7 + rand() * 1.8);
    }
    g.restore();
  });

  // Street trees on the verge, 3.2 m out from each street edge, every 11 m or so (the 3D view plants the same ones).
  for (const t of streetTreeSpots(rings)) {
    const x = px(t.x);
    const y = py(t.y);
    if (x > 0 && y > 0 && x < w && y < h) tree(g, rand, x, y, t.r * ppm);
  }
  // Light film grain so nothing reads as a flat fill
  speckle(g, rand, w, h, Math.round(w * h / 60), 1.1, ['#000000', '#ffffff'], 0.035);
  return canvasBlob(canvas);
}

function canvasBlob(canvas) {
  if (canvas.convertToBlob) return canvas.convertToBlob({ type: 'image/jpeg', quality: 0.95 });
  if (canvas.toBlob) return new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.95));
  return Promise.resolve(new Blob([canvas.toBuffer('image/jpeg', 90)], { type: 'image/jpeg' }));
}

// Path of a lot ring in the local frame (metres: a along the front edge, b into the lot) on a context that already has that transform.
function trace2(g, ring, fm, ux, uy, nx, ny) {
  g.beginPath();
  ring.forEach(([x, y], i) => {
    const dx = x - fm[0];
    const dy = y - fm[1];
    const a = dx * ux + dy * uy;
    const bb = dx * nx + dy * ny;
    g[i ? 'lineTo' : 'moveTo'](a, bb);
  });
  g.closePath();
}
