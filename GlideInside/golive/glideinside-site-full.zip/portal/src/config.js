// Brand and feature configuration. The host website overrides these (docs/SCOPE.md 12.10).
const hasWindow = typeof window !== 'undefined';
const params = hasWindow ? new URLSearchParams(window.location.search) : new URLSearchParams();
const isLocal = hasWindow && ['localhost', '127.0.0.1', '[::1]'].includes(window.location.hostname);

// false by default so a production build keeps the builder and client features closed until launch. Set true only for the
// mock/review build the owner looks at (it also turns the in-browser mock on). To open the real portal, the host page sets
// GI_CONFIG.portalEnabled = true (and the Worker needs PORTAL_ENABLED=1). See docs/PORTAL_API.md, "Going live".
const REVIEW_BUILD = false;

export const CONFIG = {
  productName: 'Glide Inside',
  // Selling entity printed on paid exports. Placeholder until decision 17.1 is made.
  seller: { name: 'JCE Infrastructure Pty Ltd trading as Glide Inside', abn: '29 699 165 663' },
  // Same origin: the Cloudflare Worker is routed at glideinside.com.au/api/* (one site, no CORS, cookie sessions stay same-site).
  apiBase: '/api',
  aiMock: false, // true serves canned assistant replies in the browser (review builds only)
  // On unless the host page sets GI_CONFIG.premiumEnabled = false. The paid version is only switched off when /api/health explicitly says payments are not configured.
  premiumEnabled: hasWindow && typeof window.GI_CONFIG?.premiumEnabled === 'boolean' ? window.GI_CONFIG.premiumEnabled : true,
  planPack: { priceAud: 30, gstInclusive: true, credits: 500, reexportMonths: 12 },
  links: {
    engineering: '', // engineering enquiry URL (configurable)
    flythrough: '',
    terms: '',
    privacy: '',
  },
  // Site lookup ("Find my block"): address search, lot boundary, DCDB neighbours, aerial and LiDAR/DEM contours (docs/SITE_LOOKUP.md).
  // siteMock true serves recorded-shape SAMPLE data from src/site/fixtures/ without calling the API (tests and review builds only).
  siteLookupEnabled: true,
  siteMock: false,
  // URL of the real NSW sample aerial (tools/fixtures/sample-aerial.jpg) for the mock lookup in a browser; null draws the synthetic picture.
  siteMockAerialUrl: null,
  // Setback rules are served statically from the site, one file per council (see tools/split-setbacks.mjs). Relative to the app page.
  setbacksBase: '../data/setbacks/',
  siteAerialMarginM: 30, // aerial and elevation grid extend this far beyond the lot boundary
  // Worldwide aerial (Mapbox Satellite) for sites outside the NSW and Queensland imagery. The PUBLIC token (pk.) is set at build time from the
  // environment variable MAPBOX_PUBLIC_TOKEN (tools/build-single.mjs writes window.__PS_MAPBOX_TOKEN__), or by the host page in
  // GI_CONFIG.mapboxToken, or read once from GET /api/health when the Worker has MAPBOX_PUBLIC_TOKEN. Empty: a grey ground is shown instead.
  // Never put a secret token (sk.) here. docs/BOUNDARY_UPLOAD.md is not needed: see UPLOAD-NOTES.md.
  mapboxToken: (hasWindow && [window.GI_CONFIG?.mapboxToken, window.__PS_MAPBOX_TOKEN__].find((t) => typeof t === 'string' && /^pk\./.test(t))) || '',
  mapboxMaxZoom: 19, // highest tile zoom asked for (the 512 pixel @2x tiles are then about 0.12 m a pixel at 37 degrees latitude)
  // Builder and client accounts (docs/PORTAL_API.md). While the back end does not exist the portal runs on the in-browser mock.
  // portalMock true runs the screens on the in-browser mock; false calls the real Worker routes (docs/PORTAL_API.md).
  // The host page can pick with GI_CONFIG.portalMock. Default: the mock only in the review build.
  portalMock: hasWindow && typeof window.GI_CONFIG?.portalMock === 'boolean' ? window.GI_CONFIG.portalMock : REVIEW_BUILD,
  // Builder and client features (portal page, client mode in Glide Inside). Off in the production config until launch;
  // on in the mock/review build. The host site can set GI_CONFIG.portalEnabled = true to open it.
  portalEnabled: hasWindow && typeof window.GI_CONFIG?.portalEnabled === 'boolean' ? window.GI_CONFIG.portalEnabled : REVIEW_BUILD,
  portal: {
    appUrl: './', // Glide Inside, relative to the portal page; the site sets GI_CONFIG.portalAppUrl
    signInUrl: '../../portal/', // the portal sign in page, relative to Glide Inside; the site sets GI_CONFIG.portalSignInUrl
    clientLoginFeeAud: 30, // per NEW client login in a calendar month, incl. GST
    aiTopUp: { credits: 300, priceAud: 10 }, // incl. GST, charged on the end of month invoice
    aiMonthlyCredits: 300, // per login per month, hard stop at zero
  },
  // The Glide Inside home page, relative to Glide Inside: where Back goes when nothing else is known. The site can set GI_CONFIG.homeUrl.
  homeUrl: (hasWindow && typeof window.GI_CONFIG?.homeUrl === 'string' && window.GI_CONFIG.homeUrl) || '../../index.html',
  autosaveKey: 'ps.autosave.v1',
  embedMode: params.get('embed') === 'demo' ? 'demo' : 'full',
  // Unlocks client-side exports for local testing only. Never true in production.
  devUnlock: isLocal && params.has('dev'),
  // STAGING ONLY: the staging site sets GI_CONFIG.staging = true. The app then asks the server for a free test Plan Pack, and the server
  // only hands one out when it runs with STAGING=1 (health reports devGrant). On the live Worker neither side exists.
  stagingGrant: hasWindow && window.GI_CONFIG?.staging === true,
  disclaimer:
    'Concept design only. Not for construction. Not a development application or complying development drawing. Not checked against planning controls, the National Construction Code or BASIX. Verify all dimensions on site.',
};
