# Submission checklist: VP523438, MBDC RFT 2026.013 Concept Design for Hawthorn Road

FP number: FP-019

**Rev G (12/10/2026, updated):** adds Sunny Lotay (RPEQ, NER), Lotay Civil, to the core team as associate reviewer and certifying engineer (FP 2.0, 5.1, 8.2, 8.3, 12.0), with a 24-hour allowance: lump sum $258,460 to $263,500 ex GST. Also adds the Glide Inside / RTK drone capability paragraph and Jayden's drone photogrammetry experience and workflow (DroneDeploy flight planning, RTK via AUSCORS or local base, check points, ReCap Pro, InfraWorks / Civil 3D, QGIS) in FP 5.1, CASA sub-2 kg excluded category with accreditation in place before services start (site more than 30 km from Adelaide Airport and Parafield), a Stage 1 line where the ReCap surface feeds the concept model, and high-resolution aerial stills and video (experience sentence, Stage 1, and a deliverables line); lodge Rev G (13 pages), not Rev F. Adds the Craig Sullivan farm drainage drone survey and the Tablelands Regional Council floodway rectification (Jayden's work while at Langtree Consulting, not a JCE project; listed first, referee Darren Quilliam) to FP 5.4, and replaces the Gunnedah levee with RAAF Base Townsville delivery for CPB Contractors (referee Maverick Parker, CPB). Experience criterion re-scored 6 to 7 (council road floodway project with a council referee, counted as Jayden's personal experience; the Brief scores consultant and key staff experience together, so no change for the Langtree Consulting correction); weighted 6.9 to 7.1.

Prepared 12/10/2026. Nothing has been sent, lodged or uploaded. Register status: draft ready (no Pursue/Pass decision yet).

**Closes:** Friday 30/10/2026, 5:00 pm Adelaide time (ACDT) = 5:30 pm NSW time. **Questions cut-off:** Tuesday 27/10/2026, 5:00 pm Adelaide time. **Sub-consultant quotes due:** 12:00 pm ACDT Friday 23/10/2026. **Decision:** 20/11/2026.

## 1. Final price summary (all excl. GST)

| Item | Amount |
|---|---|
| JCE labour (760.5 h) | $133,640 |
| Sub-consultant allowances (raw $99,000, plus 10% coordination) | $108,900 |
| Associate review and certification, Sunny Lotay (24 h at $200/hr [TBC - Jayden: associate rate]) | $4,800 |
| Disbursements | $3,610 |
| 5% risk allowance (rounded) | $12,550 |
| **Lump sum, Separable Portion 1** | **$263,500** (GST $26,350; $289,850 incl. GST). Was $258,460 before Sunny's allowance (+$5,040) |
| PC Sum SP2 Detailed Design (70%) | $221,700 |
| PC Sum SP3 IFC (100%) | $117,700 |
| **PC Sums total** | **$339,400** |

Stage split: Stage 1 $64,020; Stage 2 $138,460; Stage 3 $61,020. PC Sums unchanged (SP2/SP3 certification by Sunny to be priced if Council instructs those portions). No budget figure is published in the tender documents. Sub-consultant figures are allowances until the quotes arrive: replace them in the Cost Sheet, then update FP Sections 8.1 and 8.2 and the Schedule answers (Item 3).

## 2. Lodgement steps (Jayden, on VendorPanel)

1. Decide Pursue or Pass in the register.
2. Fold in sub-consultant quotes (due 23/10/2026), pick one firm per discipline, update FP Section 5.2 and the fee, and fill the [TBC - Jayden] items below.
3. Paste `FP_Final_text.md` into the JCE branded template (or use `JCE_FP_VP523438_Final_RevG.docx`), insert the Gantt chart (Figure 1), add the FP number (done: FP-019), sign the offer block, and export to PDF.
4. Build **one** PDF named **`2026.013 JCE Infrastructure SUBMISSION.pdf`** (Brief 10, cl 8.2), in this order:
   - Signed fee proposal Rev G (includes Attachment A, Schedule of Rates)
   - Attachment B: `Callen-Pell_NER-02_Detailed_CV.pdf`
   - Attachment C: `Certificate_of_Currency_-_2026-07-14T105420.82.pdf`; `JCE Capability Statement - Councils.pdf`; `JCE-WHS-POL-001-Work_Health_and_Safety_Policy.pdf`; `JCE-WHS-PLN-001-WHS_Management_Plan.pdf`; `JCE-WHS-PRO-011-Safety_in_Design_Procedure.pdf`; `JCE-QMS-POL-001-Quality_Policy.pdf`; `JCE-ENV-POL-001-Environmental_Policy.pdf`; `JCE-WHS-POL-003-Modern_Slavery_Policy.pdf`
   - Optional appendix: the Agreement Schedule answers (from `2026.013-...Schedule_answers.md`)
5. Log in to VendorPanel, open VP523438, check for addenda and answers to questions, attach the single PDF, complete any on-screen fields, and submit before 5:00 pm ACDT Friday 30/10/2026 (aim for Thursday 29/10/2026). Save the submission receipt to `02_Submission`.

## 3. Files

| File | Where |
|---|---|
| JCE_FP_VP523438_Final_RevG.docx / .pdf (13 pages; Rev F kept for reference) | Repo `FP/VP523438/Final/` (binary; copy to Dropbox `02_Submission` yourself) |
| FP_Final_text.md | Repo `Final/` and Dropbox `02_Submission/FINAL_2026-10-12_FP_Final_text.md` |
| SUBMISSION_CHECKLIST.md | Repo `Final/` and Dropbox `02_Submission/FINAL_2026-10-12_SUBMISSION_CHECKLIST.md` |
| RFIs_FINAL.md | Repo `Final/` and Dropbox `02_Submission/FINAL_2026-10-12_RFIs_FINAL.md` |
| 2026.013-...Draft_Services_Agreement_Schedule_answers.md | Repo `Final/` (no editable returnables exist; this answers every Agreement Schedule field and maps Brief 9) |
| vp523438_program.png (Gantt) | Embedded in the docx; source in the session scratchpad |
| CV, certificate, capability statement, policies (8 PDFs) | Already in Dropbox `02_Submission/Returnables` |
| RFQs (5 disciplines, .docx + .pdf) and Emails.txt | Repo `FP/VP523438/<Discipline>/`; emails also in Dropbox `03_Subconsultants/<Discipline>/Email_Drafts_Final_2026-10-12.txt` |

## 4. [TBC - Jayden] items

1. **Sub-consultant quotes** (due 23/10/2026): select firms, replace allowances, adjust lump sum (FP 5.2, 8.1, 8.2).
2. **Client contacts for experience** (FP 5.4, Brief 9 k): Katherine Aquatics contact. Brett Langtree and Livio Chiarot are listed as referees. Gunnedah levee removed (Jayden, 12/10/2026).
14. RAAF Base Townsville / CPB (FP 5.4): Referee name corrected to "Maverick Parker, CPB Contractors"; email Maverick.Parker@cpbcon.com.au (Jayden's Outlook, 3 Oct 2026; FP still prints "contact details available on request"). [TBC - Jayden: title, phone, consent to be named; project year (five-year windows), package scope, JCE's role (as JCE or a previous employer), value; any Defence confidentiality limits on what can be described].
3. **Current commitments** (FP 5.3, Brief 9 c).
4. **Workers compensation / accident cover**: confirm the cover held and attach a certificate (only a blank icare letter is on file); FP 11.0.
5. **Livio Chiarot**: confirm availability as independent reviewer (FP 2.0).
6. Conflict of interest declaration confirmation (FP 10.0).
7. ~~FP number (FP-0xx)~~ [x] Done: FP-019 applied. Date of issue and signature still to do.
8. Agreement Schedule: business, registered and postal addresses; ACN 699 165 663 (check); company execution (sole director and secretary?).
9. SA registration: confirm on legislation.sa.gov.au (FP 5.1).
11. Drone project example (FP 5.4, Craig Sullivan farm drainage): [TBC - Jayden: location, year, approx. area]. Get Craig Sullivan's consent to be named as a referee and his phone/email (FP prints "Referee details available on request").
13. Tablelands floodway rectification (FP 5.4; delivered by Jayden while at Langtree Consulting, presented as key personnel experience, not JCE company experience): [TBC - Jayden: site, year, value, JCE's role and scope, RPEQ sign-off arrangement]. Get Darren Quilliam's consent to be named, his title, phone and email (FP prints "contact details available on request"). Ravenshoe leachate storage facility design modification (Tablelands Regional Council, 2025, at Langtree Consulting) not used here (not relevant to road design); if used elsewhere, site and year are known (2025 is within any five-year window) and only value and Jayden's scope are TBC.
15. **Sunny Lotay (Lotay Civil):** signed standing associate agreement (scope, fee basis, availability, insurance: does JCE's PI cover his work or does Lotay Civil hold its own PI/PL? attach certificates); Sunny's written consent to be named on this bid; RPEQ and NER numbers; CV (add to Attachment B); confirm the $200/hr associate rate. Livio Chiarot no longer named as reviewer (remains a referee).
12. [TBC - Jayden to confirm] DJI Terra licence, if orthophotos are produced in DJI Terra rather than ReCap Pro.
10. Keep or drop the four requested amendments (FP 12.0). Compliance may be scored; the liability cap is the one most likely to be marked as a departure.

## 5. Insurance and certificate actions

- **PL:** PL $20M quote requested 12/10; bind before lodgement if possible and attach the certificate. FP keeps "JCE will lift PL to $20 million on award" until the policy is bound (Item 14 needs $20M; JCE holds $10M).
- **PI:** $10M any one claim / $20M aggregate held (certificate to 02/07/2027) exceeds $2M. Confirm 7-year run-off (Annexure D) is acceptable to the insurer.
- **Return to Work SA:** cl 20.15.1 requires registration; cl 10.4 says "where required by law". FP asks for the cl 20.15.6 alternative. RFI 7 asks Council to confirm.
- **Sub-consultants:** RFQs ask for $20M PL, $2M PI with 7-year run-off, and RTWSA registration (cl 10.5, 20.15.3).

## 6. SA engineer registration (checked 12/10/2026)

- The Brief and Agreement do not require CPEng, NER or State registration.
- No South Australian Act named "Professional Engineers Registration Act 2023" could be confirmed from public sources reachable from this session (legislation.sa.gov.au and cbs.sa.gov.au are blocked here). Engineers Australia (09/2023) and the SA "YourSAy" consultation describe a proposed scheme that starts with engineers in the building and construction industry. The earlier run's reading of the CBS page was that phase one covers structural and fire safety engineers on complex buildings. The "Professional Engineers Act 2023" with 2024 and 2025 start dates is an ACT law.
- **JCE position (FP 5.1):** no registration is required for civil road and drainage concept design in SA. Jayden (MIEAust, NER application in progress) leads. If a scheme starts during the commission and applies, JCE will comply, including by engaging a registered engineer. **[TBC - Jayden: check legislation.sa.gov.au for any SA engineers registration Act and its commencement before lodging.]**

## 7. RFQs to send and quotes to fold in

Send by Tuesday 13/10/2026 (one email per firm, from Jayden's mailbox, with the RFQ PDF and Council Brief):

| Discipline | Firms (email) |
|---|---|
| Survey | Steed Surveyors, Mount Barker [email TBC, (08) 8391 3000]; Alexander Symonds (adelaide@alexander.com.au); Mosel Surveyors (info@mosel.com.au) |
| Geotechnical | Aeolian Geotechnical, Mount Barker (c.eastham@aeoliangeo.com.au); Douglas Partners Adelaide [email TBC]; WGA, Brenton Harris [email TBC] |
| Traffic and RSA | SALT (adelaide@salt3.com.au); BE Engineering Solutions (info@be-engsolutions.com.au); CIRQA [email TBC] |
| Arborist | Arborman Tree Solutions (arborman@arborman.com.au); ENSPEC (craig.hallam@enspec.com); Adelaide ARB Consultants (info@adelaidearb.com.au) |
| Street lighting | Lucid Consulting Engineers [email TBC, (08) 8407 9700]; BESTEC [email TBC]; Clarence Consultants (Ken@clarenceconsultants.com.au) |

Allowances to beat or confirm (raw, before markup): survey $40,000; geotechnical $22,000; traffic and RSA $20,000; arborist $8,000; lighting $9,000. Ask WGA and Douglas Partners whether they are tendering as lead designer before relying on their quote.

## 8. Questions to lodge

Seven questions in `RFIs_FINAL.md` (PL question dropped). Lodge via VendorPanel by Wednesday 21/10/2026; hard cut-off Tuesday 27/10/2026, 5:00 pm Adelaide time.

## 9. Evaluator scores

No criteria or weightings are published. Scored as a strict council panel against criteria ranked by the Brief's emphasis (assumed weights):

| Criterion (assumed weight) | Draft Rev A | Final Rev F | With TBCs filled |
|---|---|---|---|
| Understanding and methodology (30%) | 7 | 8 | 8 |
| Team, experience and sub-consultants (25%) | 4 | 7.5 | 8 |
| Price and value (30%) | 6 | 6 | 6 to 7 (quotes) |
| Program and availability (10%) | 6 | 8 | 8 |
| Compliance, insurance and terms (5%) | 4 | 7.5 | 8 |
| **Weighted** | **5.7** | **7.2** | **7.5** |

Changes made: (1) experience section filled with Jayden's real projects and two referees; (2) PL departure replaced by a commitment to $20M on award; (3) Gantt program and SP2/SP3 activation statement (cl 2.5.7); (4) sub-consultant shortlist named, with Adelaide Hills firms, and cl 19 consent requested; (5) "how JCE manages the team" section with review before issue and one comments register. Also fixed: Schedule of Rates cross-references (Attachment A), disbursements $3,610 vs $3,790 reconciliation, payment terms to cl 3.2, lighting categories (V5 to the link road, PR5 beyond), RTWSA amendment wording (cl 20.15 vs 10.4), council-side experience statement. Remaining weakness: no named lead from each sub-consultant until quotes arrive, and price is not benchmarked against a budget.
