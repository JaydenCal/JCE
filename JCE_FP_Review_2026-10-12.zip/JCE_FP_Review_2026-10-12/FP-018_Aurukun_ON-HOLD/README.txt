FP-018 Aurukun Waste Management Facility (DLGWV2026-0370), closes Wed 28/10 2pm AEST.
On hold: clause 2.8(b) bans generative AI use. Email procurement@dlgwv.qld.gov.au (Florine Vega-Hughes) by Mon 19/10 2pm AEST to ask permission.
